import "./css/index.css";

// NOTE: polyfills for IE
import "core-js/fn/string/starts-with";
import "core-js/fn/string/ends-with"
import "core-js/fn/object/set-prototype-of"

export { App } from "./dist/app.js";