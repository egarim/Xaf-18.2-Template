export { getAppConfig as patchAppConfig } from "./dist/app.js";
export { xafModule } from "./dist/module.js";